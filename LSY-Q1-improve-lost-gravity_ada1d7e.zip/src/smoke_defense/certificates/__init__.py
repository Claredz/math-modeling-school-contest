"""Analytic feasibility certificates."""

"""Certificate tests."""
